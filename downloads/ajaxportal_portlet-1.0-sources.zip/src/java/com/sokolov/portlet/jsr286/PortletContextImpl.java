package com.sokolov.portlet.jsr286;

import javax.portlet.PortletContext;

/**
 *
 *
 * @author Sergei Sokolov
 * @version 1.0
 */
public class PortletContextImpl /*implements PortletContext*/ {

}
